-- MySQL dump 10.16  Distrib 10.1.21-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userID` int(10) DEFAULT NULL,
  `dogID` int(10) DEFAULT NULL,
  `time` varchar(40) DEFAULT NULL,
  `grooming` varchar(50) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,1,1,'2018-19-33:9:00-10:30','grooming','clean'),(3,1,1,'2018-05-18: 13:30 to 15:00','Array','fully clean'),(4,1,3,'2018-05-11: 15:00-16:30','Array',''),(5,1,1,'2018-05-24: 13:30-15:00','Array',''),(6,1,1,'2018-05-18: 16:30-18:00','nail clipping',''),(7,1,1,'2018-05-18: 16:30-18:00','nail clipping,deluxe grooming',''),(8,17,4,'2018-05-19: 13:30-15:00','wash,nail clipping,deluxe grooming','efgfdghdh'),(9,11,6,'2018-05-18: 13:30-15:00','nail clipping',''),(10,11,6,'2018-05-27: 16:30-18:00','wash',''),(12,0,0,'','',''),(13,0,0,'','',''),(14,19,8,'2018-05-19: 13:30-15:00','wash',''),(15,19,8,'2018-07-12: 9:00-10:30','nail clipping,deluxe grooming',''),(16,19,8,'2018-05-03: 13:30-15:00','deluxe grooming',''),(17,19,8,'2018-05-18: 13:30-15:00','nail clipping,deluxe grooming',''),(18,19,9,'2018-05-16: 13:30-15:00','wash',''),(19,19,9,'2018-05-19: 15:00-16:30','nail clipping,deluxe grooming','fast');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approve`
--

DROP TABLE IF EXISTS `approve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `approve` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `appointID` int(10) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approve`
--

LOCK TABLES `approve` WRITE;
/*!40000 ALTER TABLE `approve` DISABLE KEYS */;
INSERT INTO `approve` VALUES (1,10,'yes'),(2,11,'no'),(3,1,'yes'),(4,3,'no'),(5,11,'no'),(6,12,'no'),(7,13,'no'),(8,14,'no'),(9,15,'no'),(10,16,'no'),(11,17,'no'),(12,18,'no'),(13,19,'no');
/*!40000 ALTER TABLE `approve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doginfo`
--

DROP TABLE IF EXISTS `doginfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doginfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userID` int(10) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `breed` varchar(10) DEFAULT NULL,
  `birthday` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doginfo`
--

LOCK TABLES `doginfo` WRITE;
/*!40000 ALTER TABLE `doginfo` DISABLE KEYS */;
INSERT INTO `doginfo` VALUES (1,1,'coco','yes','1994-10-28'),(2,2,'jojg','yes','2194-4-4'),(3,1,'hh','yes','1849-34-45'),(4,17,'fdhdh','yes','2018-05-19'),(5,18,'ss','yes','2018-05-12'),(6,11,'qwr','fgr','2018-05-17'),(7,11,'gthyj','rtuyit','2018-04-14'),(8,19,'honey','jinmao','2017-11-16'),(9,19,'jerry','zangao','2018-07-19');
/*!40000 ALTER TABLE `doginfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'sunyunhoo@gmail.com','song19941022-'),(2,'sunyunhoo@gmail.com','song19941022-'),(3,'test1@gmail.com','123456'),(4,'test2@gmail.com','123456'),(5,'test3@gmail.com','123456'),(6,'test4@163.com','ewrrt'),(7,'test7@qq.com','qjojg'),(8,'test7@qq.com','sfgggwerr'),(9,'134',''),(10,'134',''),(11,'fanfangoouck@gmail.com','sfagha'),(12,'280971752@qq.com','34t65gdfg'),(13,'test11@132.com','sjojg'),(14,'35j1@2345.com','sjojgojgj'),(15,'',''),(16,'jwojgjg@163.com','12345'),(17,'test88@gmail.com','123'),(18,'test99@11.com','123'),(19,'doglover@gmail.com','123');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userID` int(10) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `mobileNumber` int(20) DEFAULT NULL,
  `homeNumber` int(20) DEFAULT NULL,
  `workNumber` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES (1,1,'song','33 Blackwood Street',2147483647,325235,276624),(2,0,'Tom Grooming','2202, carlton street, 3053',124565768,NULL,NULL),(3,0,'sdg','sdght',12454656,NULL,NULL),(4,0,'dojgpajhg','soow245',234567461,NULL,NULL),(5,14,'hogj','hjog341jo',1243523,1452454,2983986),(6,15,'','',0,NULL,NULL),(7,16,'jogj','jowj20498',809345892,NULL,NULL),(8,8,'3','sjjg',1243,634532413,NULL),(12,17,'sjog','jowgjo2',2435464,NULL,NULL),(13,18,'sjog','jojgio',12344,NULL,NULL),(14,11,'song','sghjk',235364,657632,2147483647),(15,19,'tester','xxxxx123xxx',334556,NULL,NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-03 20:55:38
